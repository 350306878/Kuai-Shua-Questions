var Bmob = require('../../dist/Bmob-1.6.2.min.js');
var that;
Page({

 
  data: {
    questionList: [],
    nowQuestion: [],
    nowQuestionNumber: null,
    showAnswer: false,
  },

  
  onLoad: function (options) {
    that=this;
    var index = parseInt(options.index);
    var nowQuestionList = getApp().globalData.nowQuestionList;
    console.log(nowQuestionList)
    that.setData({
      questionList: nowQuestionList,
      nowQuestion: nowQuestionList[index],
      nowQuestionNumber: index+1
    })
  },

  backHome:function(){
    wx.navigateBack({
      delta: 1
    })
  },

  showAnswer:function(){
    that.setData({
      showAnswer: true,

    })
  },

  after1: function () {
    var nowQuestionNumber = that.data.nowQuestionNumber;
    var questionList = that.data.questionList;
    if (nowQuestionNumber + 1 < 20) {
      nowQuestionNumber++;
      that.setData({
        nowQuestion: questionList[nowQuestionNumber],
        nowQuestionNumber: nowQuestionNumber,
        showAnswer: false
      })
    }
  },

  before1: function () {
    var nowQuestionNumber = that.data.nowQuestionNumber;
    var questionList = that.data.questionList;
    if (nowQuestionNumber != 0) {
      nowQuestionNumber--;
      that.setData({
        nowQuestion: questionList[nowQuestionNumber],
        nowQuestionNumber: nowQuestionNumber,
        showAnswer: false
      })
    }
  },
  onShareAppMessage: function () {

  }

  
})