var Bmob = require('../../dist/Bmob-1.6.2.min.js');
var that;
Page({

  
  data: {
    score: 0,
    nowAnswerResultList:[]
  },

  
  onLoad: function (options) { 
    that=this;
    wx.showLoading({
      title: '加载中',
    })
    var choseQB = getApp().globalData.choseQB;
    var nowAnswerResultList = getApp().globalData.nowAnswerResultList;
    var score = getApp().globalData.score;
    let current = Bmob.User.current();
    var currentUserId = current.objectId;


    const queryHistory = Bmob.Query('history');
    queryHistory.equalTo("userID", "==", currentUserId);
    queryHistory.equalTo("QB", "==", choseQB);
    queryHistory.find().then(res => {
      console.log(res)
      if(res.length==0){
        console.log('111')
        const pointer = Bmob.Pointer('_User')
        const poiID = pointer.set(currentUserId)
        queryHistory.set("score", score);
        queryHistory.set("allScore", score);
        queryHistory.set("QB", choseQB);
        queryHistory.set("frequency", 1);
        queryHistory.set("user", poiID);
        queryHistory.set("userID", currentUserId);
        queryHistory.save().then(res => {
          console.log(res)
        }).catch(err => {
          console.log(err)
        })
      }
      else{
        console.log('222')
        var allScore = res[0].allScore;
        allScore = allScore + score;
        var historyID = res[0].objectId;
        var frequency = res[0].frequency;
        frequency++;
        console.log('historyID' + historyID)
        queryHistory.destroy(historyID).then(res => {
          const pointer = Bmob.Pointer('_User')
          const poiID = pointer.set(currentUserId)
          queryHistory.set("score", score);
          queryHistory.set("allScore", allScore);
          queryHistory.set("QB", choseQB);
          queryHistory.set("frequency", frequency);
          queryHistory.set("user", poiID);
          queryHistory.set("userID", currentUserId);
          queryHistory.save().then(res => {
            console.log(res)
          }).catch(err => {
            console.log(err)
          })
        }).catch(err => {
          console.log(err)
        })
      }
    });


    const queryWA = Bmob.Query("wrongAnswer");
    queryWA.equalTo("userID", "==", currentUserId);
    queryWA.find().then(res => {
      var objectId = res[0].objectId;

      if (choseQB == '测试题库第一套') {
        var wrongAnswerList = res[0].QB1;
      }
      else if (choseQB == '测试题库第二套') {
        var wrongAnswerList = res[0].QB2;
      }
      else if (choseQB == '测试题库第三套') {
        var wrongAnswerList = res[0].QB3;
      }
      var nowWrongAnswerList = getApp().globalData.wrongAnswerList;
      for (var i = 0; i < nowWrongAnswerList.length;i++){
        wrongAnswerList.push(nowWrongAnswerList[i])
      }
      

      queryWA.set('id', objectId) //需要修改的objectId

      if (choseQB == '测试题库第一套') {
        queryWA.set('QB1', wrongAnswerList)
      }
      else if (choseQB == '测试题库第二套') {
        queryWA.set('QB2', wrongAnswerList)
      }
      else if (choseQB == '测试题库第三套') {
        queryWA.set('QB3', wrongAnswerList)
      }

    
      queryWA.save().then(res => {
        console.log(res)
      }).catch(err => {
        console.log(err)
      })
    });




    that.setData({
      nowAnswerResultList: nowAnswerResultList,
      score: score
    })
    wx.hideLoading();
  },

  showDeatil:function(e){
    var index = e.currentTarget.dataset.index;
    wx.navigateTo({
      url: '../showDetail/showDetail?index=' + index
    })
  },


  onUnload: function () {

    getApp().globalData.nowAnswerResultList=[];
    getApp().globalData.wrongAnswerList = [];
    getApp().globalData.score = 0;
    getApp().globalData.choseQB = '';
  },

  
})