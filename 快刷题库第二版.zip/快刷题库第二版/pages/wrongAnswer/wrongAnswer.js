var Bmob = require('../../dist/Bmob-1.6.2.min.js');
var that;
Page({

  
  data: {
    questionList:[],
    nowQuestion:[],
    nowQuestionNumber:0,
    objectId:'',
    questionListLength:0,
    showAnswer:false,
    choseQB:''
  },

 
  onLoad: function (options) {
    that=this;
    var choseQB = options.choseQB;
    console.log(options.choseQB)
    let current = Bmob.User.current();
    var currentUserId = current.objectId;
    const queryWA = Bmob.Query('wrongAnswer');
    queryWA.equalTo("userID", "==", currentUserId);
    queryWA.find().then(res => {
      console.log(res)

  

      console.log(choseQB)
      if (choseQB == '测试题库第一套') {
        var wrongAnswerList = res[0].QB1;
        console.log(wrongAnswerList)
        if (wrongAnswerList == 0) {
          wx.showToast({
            title: '没有错题',
            icon: 'success',
            duration: 2000
          })
          that.nextQuestion = setTimeout(function () {
            wx.navigateBack({
              delta: 2
            })
          }, 1000);
        }
      }
      else if (choseQB == '测试题库第二套') {
        var wrongAnswerList = res[0].QB2;
        if (wrongAnswerList == 0) {
          wx.showToast({
            title: '没有错题',
            icon: 'success',
            duration: 2000
          })
          that.nextQuestion = setTimeout(function () {
            wx.navigateBack({
              delta: 2
            })
          }, 1000);
        }
      }
      else if (choseQB == '测试题库第三套') {
        var wrongAnswerList = res[0].QB3;
        if (wrongAnswerList == 0) {
          wx.showToast({
            title: '没有错题',
            icon: 'success',
            duration: 2000
          })
          that.nextQuestion = setTimeout(function () {
            wx.navigateBack({
              delta: 2
            })
          }, 1000);
        }
      }

      console.log(wrongAnswerList)
      that.setData({
        choseQB: choseQB,
        questionList: wrongAnswerList,
        objectId: res[0].objectId,
        nowQuestion: wrongAnswerList[0],
        questionListLength: wrongAnswerList.length
      })
    });
  },

  remove:function(){
    var choseQB = that.data.choseQB;
    var objectId = that.data.objectId;
    var questionList = that.data.questionList;
    console.log(questionList)
    var nowQuestionNumber = that.data.nowQuestionNumber;
    questionList.splice(nowQuestionNumber, 1);
    if (questionList.length==0){
      wx.showToast({
        title: '全部删除完毕',
        icon: 'success',
        duration: 2000
      })
      that.nextQuestion = setTimeout(function () {
        wx.reLaunch({
          url: '../homePage/homePage'
        })
      }, 1000);
    }

    if (nowQuestionNumber == questionList.length){
      nowQuestionNumber-=1;
      console.log('666')
    }
 


    const queryWA = Bmob.Query('wrongAnswer');
    queryWA.set('id', objectId) //需要修改的objectId

    if (choseQB == '测试题库第一套') {
      queryWA.set('QB1', questionList)
    }
    else if (choseQB == '测试题库第二套') {
      queryWA.set('QB2', questionList)
    }
    else if (choseQB == '测试题库第三套') {
      queryWA.set('QB3', questionList)
    }

    queryWA.save().then(res => {
      that.setData({
        questionList: questionList,
        nowQuestion: questionList[nowQuestionNumber],
        questionListLength: questionList.length,
        nowQuestionNumber: nowQuestionNumber,
        showAnswer: false
      })
    }).catch(err => {
      console.log(err)
    })
  },

  after1:function(){
    var nowQuestionNumber = that.data.nowQuestionNumber;
    var questionList = that.data.questionList;
    var questionListLength = that.data.questionListLength;
    if (nowQuestionNumber+1 < questionListLength){
      nowQuestionNumber++;
      that.setData({
        nowQuestion: questionList[nowQuestionNumber],
        nowQuestionNumber: nowQuestionNumber,
        showAnswer: false
      })
    }
  },

  after10: function () {
    var nowQuestionNumber = that.data.nowQuestionNumber;
    var questionList = that.data.questionList;
    var questionListLength = that.data.questionListLength;
    if (nowQuestionNumber + 1 < questionListLength) {
      nowQuestionNumber+=10;
      if (nowQuestionNumber > questionListLength){
        nowQuestionNumber = questionListLength-1;
      }
      console.log(nowQuestionNumber)
      that.setData({
        nowQuestion: questionList[nowQuestionNumber],
        nowQuestionNumber: nowQuestionNumber,
        showAnswer: false
      })
    }
  },

  before1: function () {
    var nowQuestionNumber = that.data.nowQuestionNumber;
    var questionList = that.data.questionList;
    var questionListLength = that.data.questionListLength;
    if (nowQuestionNumber!=0) {
      nowQuestionNumber--;
      that.setData({
        nowQuestion: questionList[nowQuestionNumber],
        nowQuestionNumber: nowQuestionNumber,
        showAnswer: false
      })
    }
  },

  before10: function () {
    var nowQuestionNumber = that.data.nowQuestionNumber;
    var questionList = that.data.questionList;
    var questionListLength = that.data.questionListLength;
    if (nowQuestionNumber != 0) {
      nowQuestionNumber-=10;
      if (nowQuestionNumber < 0) {
        nowQuestionNumber = 0;
      }
      console.log(nowQuestionNumber)
      that.setData({
        nowQuestion: questionList[nowQuestionNumber],
        nowQuestionNumber: nowQuestionNumber,
        showAnswer: false
      })
    }
  },

  showAnswer:function(e){
    that.setData({
      showAnswer: true
    })
  }

  
})