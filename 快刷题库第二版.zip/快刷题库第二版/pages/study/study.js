var Bmob = require('../../dist/Bmob-1.6.2.min.js');
var that;
Page({


  data: {
    questionType:'SC',
    questionListSC: [],
    questionListJD: [],
    questionListFB: [],
    questionListBA: [],
    nowQuestion: [],
    nowQuestionNumber: 1,
    allQuestionNumber:1,
    SCAllNumber: 1,
    JDAllNumber: 1,
    FBAllNumber: 1,
    BAAllNumber: 1,
    SCNumber: 1,
    JDNumber: 1,
    FBNumber: 1,
    BANumber: 1,
    showAnswer: false,
    choseQB: '',
    QBSC: '',
    QBJD: '',
    QBFB: '',
    QBBA: '',
    nowSCNumber: 1,
    nowJDNumber: 1,
    nowFBNumber: 1,
    nowBANumber: 1,
  },

  onLoad: function (options) {
    that=this;
    wx.showLoading({
      title: '加载中...',
    })
    var choseQB = options.choseQB;
    let current = Bmob.User.current();
    var currentUserId = current.objectId;
    const queryUser = Bmob.Query('_User');
    queryUser.get(currentUserId).then(res1 => {
      if (choseQB == '测试题库第一套') {
        var SCNumber = res1.QB1Data[0].SC;
        var JDNumber = res1.QB1Data[0].JD;
        var FBNumber = res1.QB1Data[0].FB;
        var BANumber = res1.QB1Data[0].BA;
        var QBSC = 'QB1SC';
        var QBJD = 'QB1JD';
        var QBFB = 'QB1FB';
        var QBBA = 'QB1BA';
        var QBAtt = 'QB1';
      }
      else if (choseQB == '测试题库第二套') {
        var SCNumber = res1.QB2Data[0].SC;
        var JDNumber = res1.QB2Data[0].JD;
        var FBNumber = res1.QB2Data[0].FB;
        var BANumber = res1.QB2Data[0].BA;
        var QBSC = 'QB2SC';
        var QBJD = 'QB2JD';
        var QBFB = 'QB2FB';
        var QBBA = 'QB2BA';
        var QBAtt = 'QB2';
      }
      else if (choseQB == '测试题库第三套') {
        var SCNumber = res1.QB3Data[0].SC;
        var JDNumber = res1.QB3Data[0].JD;
        var FBNumber = res1.QB3Data[0].FB;
        var BANumber = res1.QB3Data[0].BA;
        var QBSC = 'QB3SC';
        var QBJD = 'QB3JD';
        var QBFB = 'QB3FB';
        var QBBA = 'QB3BA';
        var QBAtt = 'QB3';
      }
      const queryQB = Bmob.Query(QBSC);
      queryQB.equalTo("questionNumber", "==", SCNumber);
      console.log('QBSC' + QBSC)
      console.log('questionNumber' + SCNumber)
      queryQB.find().then(res2 => {


        const queryQBAtt = Bmob.Query('QBAttributes');
        queryQBAtt.equalTo("QBName", "==", QBAtt);
        queryQBAtt.find().then(res3 => {
          console.log(res3)
          var SCAllNumber = res3[0].SCNumber;
          var JDAllNumber = res3[0].JDNumber;
          var FBAllNumber = res3[0].FBNumber;
          var BAAllNumber = res3[0].BANumber;
          var allQuestionNumber = SCAllNumber;
          that.setData({
            choseQB: choseQB,
            nowQuestion: res2[0],
            nowQuestionNumber: SCNumber,
            allQuestionNumber: allQuestionNumber,
            QBSC: QBSC,
            QBJD: QBJD,
            QBFB: QBFB,
            QBBA: QBBA,
            SCAllNumber:  SCAllNumber,
            JDAllNumber:  JDAllNumber,
            FBAllNumber: FBAllNumber,
            BAAllNumber:  BAAllNumber,
            SCNumber:  SCNumber,
            JDNumber:  JDNumber,
            FBNumber:  FBNumber,
            BANumber: BANumber,
            nowSCNumber: SCNumber,
            nowJDNumber: JDNumber,
            nowFBNumber: FBNumber,
            nowBANumber: BANumber,
          })
          wx.hideLoading()
        });
      });

    }).catch(err => {
      console.log(err)
    })
  },

  after1:function(){
    var questionType = that.data.questionType;
    var allQuestionNumber = that.data.allQuestionNumber;
    var searchQBTable;
    var nowSCNumber = that.data.nowSCNumber;
    var nowJDNumber = that.data.nowJDNumber;
    var nowFBNumber = that.data.nowFBNumber;
    var nowBANumber = that.data.nowBANumber;
    
    var nowQuestionNumber = that.data.nowQuestionNumber;
    if (nowQuestionNumber < allQuestionNumber){
      nowQuestionNumber++;
      if (questionType == 'SC') {
        searchQBTable = that.data.QBSC;
        nowSCNumber++;
      }
      else if (questionType == 'JD') {
        searchQBTable = that.data.QBJD;
        nowJDNumber++;
      }
      else if (questionType == 'FB') {
        searchQBTable = that.data.QBFB;
        nowFBNumber++;
      }
      else if (questionType == 'BA') {
        searchQBTable = that.data.QBBA;
        nowBANumber++;
      }
      const queryQB = Bmob.Query(searchQBTable);
      queryQB.equalTo("questionNumber", "==", nowQuestionNumber);
      queryQB.find().then(res => {
        if (questionType == 'SC') {
          that.setData({
            nowQuestion: res[0],
            nowQuestionNumber: nowQuestionNumber,
            nowSCNumber: nowQuestionNumber,
            nowSCNumber: nowSCNumber,
            showAnswer: false
          })
        }
        else if (questionType == 'JD') {
          that.setData({
            nowQuestion: res[0],
            nowQuestionNumber: nowQuestionNumber,
            nowJDNumber: nowQuestionNumber,
            nowJDNumber: nowJDNumber,
            showAnswer: false
          })
        }
        else if (questionType == 'FB') {
          that.setData({
            nowQuestion: res[0],
            nowQuestionNumber: nowQuestionNumber,
            nowFBNumber: nowQuestionNumber,
            nowFBNumber: nowFBNumber,
            showAnswer: false
          })
        }
        else if (questionType == 'BA') {
          that.setData({
            nowQuestion: res[0],
            nowQuestionNumber: nowQuestionNumber,
            nowBANumber: nowQuestionNumber,
            nowBANumber: nowBANumber,
            showAnswer: false
          })
        }
      });
    }
    
  },

  after10: function () {
    var nowSCNumber = that.data.nowSCNumber;
    var nowJDNumber = that.data.nowJDNumber;
    var nowFBNumber = that.data.nowFBNumber;
    var nowBANumber = that.data.nowBANumber;
    var questionType = that.data.questionType;
    var allQuestionNumber = that.data.allQuestionNumber;
    var searchQBTable;
    var nowQuestionNumber = that.data.nowQuestionNumber;
    nowQuestionNumber+=10;
    if (nowQuestionNumber > allQuestionNumber) {
      nowQuestionNumber = allQuestionNumber;
      nowSCNumber = allQuestionNumber;
      nowJDNumber = allQuestionNumber;
      nowFBNumber = allQuestionNumber;
      nowBANumber = allQuestionNumber;
    }
    else{
      if (questionType == 'SC') {
        searchQBTable = that.data.QBSC;
        nowSCNumber += 10;
      }
      else if (questionType == 'JD') {
        searchQBTable = that.data.QBJD;
        nowJDNumber += 10;
      }
      else if (questionType == 'FB') {
        searchQBTable = that.data.QBFB;
        nowFBNumber += 10;
      }
      else if (questionType == 'BA') {
        searchQBTable = that.data.QBBA;
        nowBANumber += 10;
      }
    }
    const queryQB = Bmob.Query(searchQBTable);
    queryQB.equalTo("questionNumber", "==", nowQuestionNumber);
    queryQB.find().then(res => {
      if (questionType == 'SC') {
        that.setData({
          nowQuestion: res[0],
          nowQuestionNumber: nowQuestionNumber,
          nowSCNumber: nowQuestionNumber,
          nowSCNumber: nowSCNumber,
          showAnswer: false
        })
      }
      else if (questionType == 'JD') {
        that.setData({
          nowQuestion: res[0],
          nowQuestionNumber: nowQuestionNumber,
          nowJDNumber: nowQuestionNumber,
          nowJDNumber: nowJDNumber,
          showAnswer: false
        })
      }
      else if (questionType == 'FB') {
        that.setData({
          nowQuestion: res[0],
          nowQuestionNumber: nowQuestionNumber,
          nowFBNumber: nowQuestionNumber,
          nowFBNumber: nowFBNumber,
          showAnswer: false
        })
      }
      else if (questionType == 'BA') {
        that.setData({
          nowQuestion: res[0],
          nowQuestionNumber: nowQuestionNumber,
          nowBANumber: nowQuestionNumber,
          nowBANumber: nowBANumber,
          showAnswer: false
        })
      }
    });
  },

  before1: function () {
    var nowSCNumber = that.data.nowSCNumber;
    var nowJDNumber = that.data.nowJDNumber;
    var nowFBNumber = that.data.nowFBNumber;
    var nowBANumber = that.data.nowBANumber;
    var questionType = that.data.questionType;
    var allQuestionNumber = that.data.allQuestionNumber;
    var searchQBTable;
    var nowQuestionNumber = that.data.nowQuestionNumber;
    if (nowQuestionNumber !=1) {
      nowQuestionNumber--;
      if (questionType == 'SC') {
        searchQBTable = that.data.QBSC;
        nowSCNumber--;
      }
      else if (questionType == 'JD') {
        searchQBTable = that.data.QBJD;
        nowJDNumber--;
      }
      else if (questionType == 'FB') {
        searchQBTable = that.data.QBFB;
        nowFBNumber--;
      }
      else if (questionType == 'BA') {
        searchQBTable = that.data.QBBA;
        nowBANumber--;
      }
      const queryQB = Bmob.Query(searchQBTable);
      queryQB.equalTo("questionNumber", "==", nowQuestionNumber);
      queryQB.find().then(res => {
        if (questionType == 'SC') {
          that.setData({
            nowQuestion: res[0],
            nowQuestionNumber: nowQuestionNumber,
            nowSCNumber: nowQuestionNumber,
            nowSCNumber: nowSCNumber,
            showAnswer: false
          })
        }
        else if (questionType == 'JD') {
          that.setData({
            nowQuestion: res[0],
            nowQuestionNumber: nowQuestionNumber,
            nowJDNumber: nowQuestionNumber,
            nowJDNumber: nowJDNumber,
            showAnswer: false
          })
        }
        else if (questionType == 'FB') {
          that.setData({
            nowQuestion: res[0],
            nowQuestionNumber: nowQuestionNumber,
            nowFBNumber: nowQuestionNumber,
            nowFBNumber: nowFBNumber,
            showAnswer: false
          })
        }
        else if (questionType == 'BA') {
          that.setData({
            nowQuestion: res[0],
            nowQuestionNumber: nowQuestionNumber,
            nowBANumber: nowQuestionNumber,
            nowBANumber: nowBANumber,
            showAnswer: false
          })
        }
      });
    }

  },

  before10: function () {
    var nowSCNumber = that.data.nowSCNumber;
    var nowJDNumber = that.data.nowJDNumber;
    var nowFBNumber = that.data.nowFBNumber;
    var nowBANumber = that.data.nowBANumber;
    var questionType = that.data.questionType;
    var allQuestionNumber = that.data.allQuestionNumber;
    var searchQBTable;
    var nowQuestionNumber = that.data.nowQuestionNumber;
    if (nowQuestionNumber != 1) {
      nowQuestionNumber-=10;
      if (nowQuestionNumber < 0) {
        nowQuestionNumber = 1;
        nowSCNumber = 1;
        nowJDNumber = 1;
        nowFBNumber = 1;
        nowBANumber = 1;
      }
      if (questionType == 'SC') {
        searchQBTable = that.data.QBSC;
        nowSCNumber-=10;
        if (nowSCNumber < 0) {
          nowSCNumber = 1;
        }
      }
      else if (questionType == 'JD') {
        searchQBTable = that.data.QBJD;
        nowJDNumber -= 10;
        if (nowJDNumber < 0) {
          nowJDNumber = 1;
        }
      }
      else if (questionType == 'FB') {
        searchQBTable = that.data.QBFB;
        nowFBNumber -= 10;
        if (nowFBNumber < 0) {
          nowFBNumber = 1;
        }
      }
      else if (questionType == 'BA') {
        searchQBTable = that.data.QBBA;
        nowBANumber -= 10;
        if (nowBANumber < 0) {
          nowBANumber = 1;
        }
      }
      const queryQB = Bmob.Query(searchQBTable);
      queryQB.equalTo("questionNumber", "==", nowQuestionNumber);
      queryQB.find().then(res => {
        if (questionType == 'SC') {
          that.setData({
            nowQuestion: res[0],
            nowQuestionNumber: nowQuestionNumber,
            nowSCNumber: nowQuestionNumber,
            nowSCNumber: nowSCNumber,
            showAnswer: false
          })
        }
        else if (questionType == 'JD') {
          that.setData({
            nowQuestion: res[0],
            nowQuestionNumber: nowQuestionNumber,
            nowJDNumber: nowQuestionNumber,
            nowJDNumber: nowJDNumber,
            showAnswer: false
          })
        }
        else if (questionType == 'FB') {
          that.setData({
            nowQuestion: res[0],
            nowQuestionNumber: nowQuestionNumber,
            nowFBNumber: nowQuestionNumber,
            nowFBNumber: nowFBNumber,
            showAnswer: false
          })
        }
        else if (questionType == 'BA') {
          that.setData({
            nowQuestion: res[0],
            nowQuestionNumber: nowQuestionNumber,
            nowBANumber: nowQuestionNumber,
            nowBANumber: nowBANumber,
            showAnswer: false
          })
        }
      });
    }

  },

  SC:function(){
    var choseQB = that.data.choseQB;
    var SCAllNumber = that.data.SCAllNumber;
    var SCNumber = that.data.SCNumber;
    var QBSC = that.data.QBSC;
    console.log('SCAllNumber' + SCAllNumber)
    console.log('SCNumber' + SCNumber)
    console.log('QBSC' + QBSC)
      const queryQB = Bmob.Query(QBSC);
      queryQB.equalTo("questionNumber", "==", SCNumber);
      queryQB.find().then(res2 => {
        that.setData({
          nowQuestion: res2[0],
          nowQuestionNumber: SCNumber,
          allQuestionNumber: SCAllNumber,
          questionType:'SC',
          showAnswer: false
        })
      });
  },

  JD: function () {
    var choseQB = that.data.choseQB;
    var JDAllNumber = that.data.JDAllNumber;
    var JDNumber = that.data.JDNumber;
    var QBJD = that.data.QBJD;
    console.log('JDAllNumber' + JDAllNumber)
    console.log('JDNumber' + JDNumber)
    console.log('QBJD' + QBJD)
    const queryQB = Bmob.Query(QBJD);
    queryQB.equalTo("questionNumber", "==", JDNumber);
    queryQB.find().then(res2 => {
      that.setData({
        nowQuestion: res2[0],
        nowQuestionNumber: JDNumber,
        allQuestionNumber: JDAllNumber,
        questionType: 'JD',
        showAnswer: false
      })
    });
  },

  FB: function () {
    var choseQB = that.data.choseQB;
    var FBAllNumber = that.data.FBAllNumber;
    var FBNumber = that.data.FBNumber;
    var QBFB = that.data.QBFB;
    console.log('FBAllNumber' + FBAllNumber)
    console.log('FBNumber' + FBNumber)
    console.log('QBFB' + QBFB)
    const queryQB = Bmob.Query(QBFB);
    queryQB.equalTo("questionNumber", "==", FBNumber);
    queryQB.find().then(res2 => {
      that.setData({
        nowQuestion: res2[0],
        nowQuestionNumber: FBNumber,
        allQuestionNumber: FBAllNumber,
        questionType: 'FB',
        showAnswer: false
      })
    });
  },


  BA: function () {
    var choseQB = that.data.choseQB;
    var BAAllNumber = that.data.BAAllNumber;
    var BANumber = that.data.BANumber;
    var QBBA = that.data.QBBA;
    console.log('BAAllNumber' + BAAllNumber)
    console.log('BANumber' + BANumber)
    console.log('QBBA' + QBBA)
    const queryQB = Bmob.Query(QBBA);
    queryQB.equalTo("questionNumber", "==", BANumber);
    queryQB.find().then(res2 => {
      that.setData({
        nowQuestion: res2[0],
        nowQuestionNumber: BANumber,
        allQuestionNumber: BAAllNumber,
        questionType: 'BA',
        showAnswer: false
      })
    });
  },

  showAnswer: function (e) {
    that.setData({
      showAnswer: true
    })
  },

  onUnload: function () {
    var QBData=new Object;
    QBData.SC = that.data.nowSCNumber;
    QBData.JD = that.data.nowJDNumber;
    QBData.FB = that.data.nowFBNumber;
    QBData.BA = that.data.nowBANumber;
    var choseQB = that.data.choseQB
    let current = Bmob.User.current();
    var currentUserId = current.objectId;
    var QBDataArry=new Array;
    QBDataArry[0] = QBData;
    console.log(QBDataArry)
    const queryUser = Bmob.Query('_User');
    queryUser.get(currentUserId).then(res => {
      if (choseQB == '测试题库第一套') {
        res.set('QB1Data', QBDataArry)
        res.save()
      }
      else if (choseQB == '测试题库第二套') {
        res.set('QB2Data', QBDataArry)
        res.save()
      }
      else if (choseQB == '测试题库第三套') {
        res.set('QB3Data', QBDataArry)
        res.save()
      }
    })
  },

  
})