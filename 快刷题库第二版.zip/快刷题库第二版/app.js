var Bmob = require('dist/Bmob-1.6.2.min.js');
Bmob.initialize("", "");
App({
  onLaunch: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.screenWidth = res.windowWidth;
        that.screenHeight = res.windowHeight;
        that.pixelRatio = res.pixelRatio;
      }
    });
    Bmob.User.auth().then(res => {
      console.log(res)
      var currentUserId = res.objectId;
      var register = res.register;
      if(register!=true){
        const queryUser = Bmob.Query('_User');
        queryUser.get(currentUserId).then(res => {
          res.set('register', false)
          res.save()
        }).catch(err => {
          console.log(err)
        })
      }
    }).catch(err => {
      console.log(err);
     
    });

 
  },
  globalData: {
    userInfo: null,
    nowQuestionList:[],
    nowAnswerResultList: [],
    wrongAnswerList: [],
    score:0,
    choseQB:'',
  }
})