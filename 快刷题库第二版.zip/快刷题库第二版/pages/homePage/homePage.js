var Bmob = require('../../dist/Bmob-1.6.2.min.js');
var that;
var app = getApp();
Page({

  data: {
    name:'未登录',
    department: '未登录',
    userPic:'../../images/signIn.png',
    register:null,
    QBArray: ['测试题库第一套', '测试题库第二套', '测试题库第三套'],
  },

 
  onLoad: function (options) {
    wx.showLoading({
      title: '登录中...',
    })
    that=this;
    
      var interval = setInterval(function () {
        let current = Bmob.User.current();
        var currentUserId = current.objectId;
        if (currentUserId) {
          clearInterval(interval);
          const queryUser = Bmob.Query('_User');
          queryUser.get(currentUserId).then(res => {
            console.log('res')
            that.setData({
              userPic: res.userPic,
              register: res.register,
              name: res.realName,
              department: res.department,
            })
            wx.hideLoading()
          }).catch(err => {
            console.log(err)
          })
        }
      }, 500);

 
  },

  getUserInfo:function(e){
 
    var register = that.data.register;
    console.log(register)
    if (register!=true){
      wx.showLoading({
        title: '登录中...',
      })
      var userInfo = e.detail.userInfo;
      var nickName = userInfo.nickName;
      var userPic = userInfo.avatarUrl;
      that.setData({
        userPic: userPic,
      })
      let current = Bmob.User.current();
      var currentUserId = current.objectId;
      const queryUser = Bmob.Query('_User');
      queryUser.get(currentUserId).then(res => {
        res.set('nickName', nickName)
        res.set("userPic", userPic);
        res.save()
        wx.hideLoading()
        wx.navigateTo({
          url: '../register/register'
        })
      }).catch(err => {
        console.log(err)
      })
    }
    else{

      var userInfo = e.detail.userInfo;
      var nickName = userInfo.nickName;
      var userPic = userInfo.avatarUrl;
      that.setData({
        userPic: userPic,
      })
      let current = Bmob.User.current();
      var currentUserId = current.objectId;
      const queryUser = Bmob.Query('_User');
      queryUser.get(currentUserId).then(res => {
        res.set('nickName', nickName)
        res.set("userPic", userPic);
        res.save()
      
        wx.navigateTo({
          url: '../me/me'
        })
      }).catch(err => {
        console.log(err)
      })

    }
  },

  answer:function(e){
    var register = that.data.register;
    if (register != true){
      wx.navigateTo({
        url: '../register/register'
      })
    }
    else{
      var choseQB = that.data.QBArray[e.detail.value]
      getApp().globalData.choseQB = choseQB;
      wx.navigateTo({
        url: '../answer/answer'
      })
    }
   
  },

  wrong: function (e) {
    var register = that.data.register;
    if (register != true) {
      wx.navigateTo({
        url: '../register/register'
      })
    }
    else{
      var choseQB = that.data.QBArray[e.detail.value]
      wx.navigateTo({
        url: '../wrongAnswer/wrongAnswer?choseQB=' + choseQB
      })
    }
   
  },

  study: function (e) {
    var register = that.data.register;
    if (register != true) {
      wx.navigateTo({
        url: '../register/register'
      })
    }
    else{
      var choseQB = that.data.QBArray[e.detail.value]
      wx.navigateTo({
        url: '../study/study?choseQB=' + choseQB
      })
    }
    
  },

  rank: function (e) {
    var register = that.data.register;
    if (register != true) {
      wx.navigateTo({
        url: '../register/register'
      })
    }
    else{
      var choseQB = that.data.QBArray[e.detail.value]
      wx.navigateTo({
        url: '../rank/rank?choseQB=' + choseQB
      })
    }
  }

 
})