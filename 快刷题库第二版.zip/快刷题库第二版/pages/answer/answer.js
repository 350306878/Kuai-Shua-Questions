var Bmob = require('../../dist/Bmob-1.6.2.min.js');
var that;
Page({


  data: {
    SCNumberList:[],
    JDNumberList: [],
    SCList:[],
    JDList: [],
    nowQuestion:[],
    choseA: false,
    choseB: false,
    choseC: false,
    choseD: false,
    nowQuestionNumber:0,
    wrongAnswerList:[],
    questionType:'SC',
    questionTypeCH:'单项选择',
    score:0
  },


  onLoad: function (options) {
    that=this;
    wx.showLoading({
      title: '加载中',
    })
    var choseQB = getApp().globalData.choseQB;
    console.log('choseQB' + choseQB)
    var SCNumberList=[];
    var JDNumberList = [];
    var SCNumber;
    var JDNumber;
    var QBAttId;
    var QBSC;
    var QBJD;



    if (choseQB == '测试题库第一套') {
      QBSC ='QB1SC';
      QBJD ='QB1JD';
      QBAttId ='65be533e14';
      console.log("111")
    }
    else if (choseQB == '测试题库第二套') {
      QBSC = 'QB2SC';
      QBJD = 'QB2JD';
      QBAttId = 'a913b88068';
      console.log("222")
    }
    else if (choseQB == '测试题库第三套') {
      QBSC = 'QB3SC';
      QBJD = 'QB3JD';
      QBAttId = '34a1fbfa88';
      console.log("333")
    }

    const queryQBAtt = Bmob.Query('QBAttributes');
    queryQBAtt.get(QBAttId).then(res => {
      console.log(res)
      SCNumber = res.SCNumber;
      JDNumber = res.JDNumber;

      while (true) {
        var isExists = false;
        var random = parseInt(Math.random() * JDNumber, 10) + 1;
        for (var i = 0; i < SCNumberList.length; i++) {
          if (random === SCNumberList[i]) {
            isExists = true;
            break;
          }
        }
        if (!isExists)
          SCNumberList.push(random);
        if (SCNumberList.length === 10)
          break;
      }
      console.log(SCNumberList)



      while (true) {
        var isExists = false;
        var random = parseInt(Math.random() * JDNumber, 10) + 1;
        for (var i = 0; i < JDNumberList.length; i++) {
          if (random === JDNumberList[i]) {
            isExists = true;
            break;
          }
        }
        if (!isExists)
          JDNumberList.push(random);
        if (JDNumberList.length === 10)
          break;
      }

      console.log(JDNumberList)
      const queryQBSC = Bmob.Query(QBSC);
      const query1QBSC = queryQBSC.equalTo("questionNumber", '==', SCNumberList[0]);
      const query2QBSC = queryQBSC.equalTo("questionNumber", '==', SCNumberList[1]);
      const query3QBSC = queryQBSC.equalTo("questionNumber", '==', SCNumberList[2]);
      const query4QBSC = queryQBSC.equalTo("questionNumber", '==', SCNumberList[3]);
      const query5QBSC = queryQBSC.equalTo("questionNumber", '==', SCNumberList[4]);
      const query6QBSC = queryQBSC.equalTo("questionNumber", '==', SCNumberList[5]);
      const query7QBSC = queryQBSC.equalTo("questionNumber", '==', SCNumberList[6]);
      const query8QBSC = queryQBSC.equalTo("questionNumber", '==', SCNumberList[7]);
      const query9QBSC = queryQBSC.equalTo("questionNumber", '==', SCNumberList[8]);
      const query10QBSC = queryQBSC.equalTo("questionNumber", '==', SCNumberList[9]);

      queryQBSC.or(query1QBSC, query2QBSC, query3QBSC, query4QBSC, query5QBSC, query6QBSC, query7QBSC, query8QBSC, query9QBSC, query10QBSC);
      queryQBSC.find().then(resSC => {
        console.log(resSC);

        const queryQBJD = Bmob.Query(QBJD);
        const query1QBJD = queryQBJD.equalTo("questionNumber", '==', JDNumberList[0]);
        const query2QBJD = queryQBJD.equalTo("questionNumber", '==', JDNumberList[1]);
        const query3QBJD = queryQBJD.equalTo("questionNumber", '==', JDNumberList[2]);
        const query4QBJD = queryQBJD.equalTo("questionNumber", '==', JDNumberList[3]);
        const query5QBJD = queryQBJD.equalTo("questionNumber", '==', JDNumberList[4]);
        const query6QBJD = queryQBJD.equalTo("questionNumber", '==', JDNumberList[5]);
        const query7QBJD = queryQBJD.equalTo("questionNumber", '==', JDNumberList[6]);
        const query8QBJD = queryQBJD.equalTo("questionNumber", '==', JDNumberList[7]);
        const query9QBJD = queryQBJD.equalTo("questionNumber", '==', JDNumberList[8]);
        const query10QBJD = queryQBJD.equalTo("questionNumber", '==', JDNumberList[9]);
        queryQBJD.or(query1QBJD, query2QBJD, query3QBJD, query4QBJD, query5QBJD, query6QBJD, query7QBJD, query8QBJD, query9QBJD, query10QBJD);
        queryQBJD.find().then(resJD => {
          console.log(resJD);
          getApp().globalData.nowQuestionList = resSC.concat(resJD);
          that.setData({
            SCList: resSC,
            JDList: resJD,
            nowQuestion: resSC[0],
            SCNumberList: SCNumberList,
            JDNumberList: JDNumberList
          });
          wx.hideLoading();
        }).catch(err => {
          console.log(err)
        })
       
      });
      
    }).catch(err => {
      console.log(err)
    })
  },

  choseItem: function (e) {
    var choseItem = e.currentTarget.dataset.choseitem;
    var nowQuestion = that.data.nowQuestion;
    var answer = nowQuestion.answer;
    var options = nowQuestion.options;
    var SCList = that.data.SCList;
    var JDList = that.data.JDList;
    var userResult=false;
    var SCNumberList = that.data.SCNumberList;
    var nowQuestionNumber = that.data.nowQuestionNumber;
    console.log(nowQuestionNumber)
    var score = that.data.score;
    console.log('qqqqscore' + score);
    ////////////////////////////////////A////////////////////////////////////////////
    if (choseItem == 'A') {
      for (var i = 0; i < options.length;i++){
        if ('A' == answer){
          console.log('answer' + answer)
          userResult = true;
          score =score+5;
          getApp().globalData.score = score;
          console.log('score' + score)
          that.setData({
            score: score,
          });
          break;
        }
       
      }
      var nowAnswerResult = new Object;
      nowAnswerResult.question = nowQuestion;
      nowAnswerResult.userResult = userResult;
      if (userResult==true){
        getApp().globalData.nowAnswerResultList.push(nowAnswerResult)
      }
      else{
        getApp().globalData.nowAnswerResultList.push(nowAnswerResult);
        getApp().globalData.wrongAnswerList.push(nowQuestion)
      }
        that.setData({
          choseA: true,
        });
        that.nextQuestion = setTimeout(function () { 
          if (nowQuestionNumber<9){
            that.setData({
              nowQuestion: SCList[nowQuestionNumber + 1],
              nowQuestionNumber: nowQuestionNumber + 1,
              choseA: false,
            });
          }
          else if (nowQuestionNumber >= 9 && nowQuestionNumber!=19){
            that.setData({
              nowQuestion: JDList[nowQuestionNumber - 10 + 1],
              nowQuestionNumber: nowQuestionNumber + 1,
              choseA: false,
              questionType: 'JD',
              questionTypeCH: '判断题'
            });
          }
          else if (nowQuestionNumber == 19){
            wx.redirectTo({
              url: '../result/result'
            })
          }
          
          
          console.log(getApp().globalData.nowAnswerResultList)
          console.log(getApp().globalData.wrongAnswerList)
        }, 300);
    }
    ////////////////////////////////////A////////////////////////////////////////////

    ////////////////////////////////////B////////////////////////////////////////////
    if (choseItem == 'B') {
      for (var i = 0; i < options.length; i++) {
        if ('B' == answer) {
          console.log('answer' + answer)
          userResult = true;
          score = score + 5;
          getApp().globalData.score = score;
          console.log('score' + score)
          that.setData({
            score: score,
          });
          break;
        }

      }
      var nowAnswerResult = new Object;
      nowAnswerResult.question = nowQuestion;
      nowAnswerResult.userResult = userResult;
      if (userResult == true) {
        getApp().globalData.nowAnswerResultList.push(nowAnswerResult)
      }
      else {
        getApp().globalData.nowAnswerResultList.push(nowAnswerResult);
        getApp().globalData.wrongAnswerList.push(nowQuestion)
      }
      that.setData({
        choseB: true,
      });
      that.nextQuestion = setTimeout(function () {
        if (nowQuestionNumber < 9) {
          that.setData({
            nowQuestion: SCList[nowQuestionNumber + 1],
            nowQuestionNumber: nowQuestionNumber + 1,
            choseB: false,
          });
        }
        else if (nowQuestionNumber >= 9 && nowQuestionNumber != 19) {
          that.setData({
            nowQuestion: JDList[nowQuestionNumber - 10 + 1],
            nowQuestionNumber: nowQuestionNumber + 1,
            choseB: false,
            questionType: 'JD',
            questionTypeCH: '判断题'
          });
        }
        else if (nowQuestionNumber == 19) {
          wx.redirectTo({
            url: '../result/result'
          })
        }


        console.log(getApp().globalData.nowAnswerResultList)
        console.log(getApp().globalData.wrongAnswerList)
      }, 300);
    }
    ////////////////////////////////////B////////////////////////////////////////////

    ////////////////////////////////////C////////////////////////////////////////////
    if (choseItem == 'C') {
      for (var i = 0; i < options.length; i++) {
        if ('C' == answer) {
          console.log('answer' + answer)
          userResult = true;
          score = score + 5;
          getApp().globalData.score = score;
          console.log('score' + score)
          that.setData({
            score: score,
          });
          break;
        }

      }
      var nowAnswerResult = new Object;
      nowAnswerResult.question = nowQuestion;
      nowAnswerResult.userResult = userResult;
      if (userResult == true) {
        getApp().globalData.nowAnswerResultList.push(nowAnswerResult)
      }
      else {
        getApp().globalData.nowAnswerResultList.push(nowAnswerResult);
        getApp().globalData.wrongAnswerList.push(nowQuestion)
      }
      that.setData({
        choseC: true,
      });
      that.nextQuestion = setTimeout(function () {
        if (nowQuestionNumber < 9) {
          that.setData({
            nowQuestion: SCList[nowQuestionNumber + 1],
            nowQuestionNumber: nowQuestionNumber + 1,
            choseC: false,
          });
        }
        else if (nowQuestionNumber >= 9 && nowQuestionNumber != 19) {
          that.setData({
            nowQuestion: JDList[nowQuestionNumber - 10 + 1],
            nowQuestionNumber: nowQuestionNumber + 1,
            choseC: false,
            questionType: 'JD',
            questionTypeCH: '判断题'
          });
        }
        else if (nowQuestionNumber == 19) {
          wx.redirectTo({
            url: '../result/result'
          })
        }

        console.log(getApp().globalData.nowAnswerResultList)
        console.log(getApp().globalData.wrongAnswerList)
      }, 300);
    }
    ////////////////////////////////////C////////////////////////////////////////////

    ////////////////////////////////////D////////////////////////////////////////////
    if (choseItem == 'D') {
      for (var i = 0; i < options.length; i++) {
        if ('D' == answer) {
          console.log('answer' + answer)
          userResult = true;
          score = score + 5;
          getApp().globalData.score = score;
          console.log('score' + score)
          that.setData({
            score: score,
          });
          break;
        }

      }
      var nowAnswerResult = new Object;
      nowAnswerResult.question = nowQuestion;
      nowAnswerResult.userResult = userResult;
      if (userResult == true) {
        getApp().globalData.nowAnswerResultList.push(nowAnswerResult)
      }
      else {
        getApp().globalData.nowAnswerResultList.push(nowAnswerResult);
        getApp().globalData.wrongAnswerList.push(nowQuestion)
      }
      that.setData({
        choseD: true,
      });
      that.nextQuestion = setTimeout(function () {
        if (nowQuestionNumber < 9) {
          that.setData({
            nowQuestion: SCList[nowQuestionNumber + 1],
            nowQuestionNumber: nowQuestionNumber + 1,
            choseD: false,
          });
        }
        else if (nowQuestionNumber >= 9 && nowQuestionNumber != 19) {
          that.setData({
            nowQuestion: JDList[nowQuestionNumber - 10 + 1],
            nowQuestionNumber: nowQuestionNumber + 1,
            choseD: false,
            questionType: 'JD',
            questionTypeCH: '判断题'
          });
        }
        else if (nowQuestionNumber == 19) {
          wx.redirectTo({
            url: '../result/result'
          })
        }

        console.log(getApp().globalData.nowAnswerResultList)
        console.log(getApp().globalData.wrongAnswerList)
      }, 300);
    }
    ////////////////////////////////////D////////////////////////////////////////////
   
  },

  submit:function(){
    wx.redirectTo({
      url: '../result/result'
    })
  }

 
})